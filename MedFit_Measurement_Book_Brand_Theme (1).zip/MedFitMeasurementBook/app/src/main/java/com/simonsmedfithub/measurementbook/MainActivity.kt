package com.simonsmedfithub.measurementbook

import android.app.Activity
import android.app.AlertDialog
import android.content.ContentValues
import android.content.Intent
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.graphics.*
import android.graphics.pdf.PdfDocument
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.*
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

// Simon's MedFit Hub brand palette: navy, white and sky blue
private val LIME = Color.rgb(18, 48, 74) // retained constant name; now brand navy
private val DEEP = Color.rgb(18, 48, 74)
private val PALE = Color.rgb(232, 246, 253) // pale sky blue
private val INK = Color.rgb(25, 38, 50)
private val SKY = Color.rgb(77, 184, 232)

data class Customer(
    val id: Long = 0, val name: String, val phone: String, val gender: String,
    val email: String, val date: String, val style: String, val notes: String,
    val unit: String, val measurements: JSONObject
)

class DbHelper(ctx: Activity) : SQLiteOpenHelper(ctx, "medfit_records.db", null, 1) {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("""CREATE TABLE customers(
            id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, phone TEXT, gender TEXT,
            email TEXT, date TEXT, style TEXT, notes TEXT, unit TEXT, measurements TEXT)""")
    }
    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {}
    fun all(): List<Customer> {
        val out = mutableListOf<Customer>()
        readableDatabase.rawQuery("SELECT * FROM customers ORDER BY id DESC", null).use { c ->
            while (c.moveToNext()) out.add(Customer(
                c.getLong(0), c.getString(1) ?: "", c.getString(2) ?: "", c.getString(3) ?: "",
                c.getString(4) ?: "", c.getString(5) ?: "", c.getString(6) ?: "",
                c.getString(7) ?: "", c.getString(8) ?: "in",
                runCatching { JSONObject(c.getString(9) ?: "{}") }.getOrDefault(JSONObject())
            ))
        }
        return out
    }
    fun save(c: Customer): Long {
        val v = ContentValues().apply {
            put("name", c.name); put("phone", c.phone); put("gender", c.gender)
            put("email", c.email); put("date", c.date); put("style", c.style)
            put("notes", c.notes); put("unit", c.unit); put("measurements", c.measurements.toString())
        }
        return if (c.id > 0) {
            writableDatabase.update("customers", v, "id=?", arrayOf(c.id.toString()))
            c.id
        } else writableDatabase.insert("customers", null, v)
    }
    fun delete(id: Long) { writableDatabase.delete("customers", "id=?", arrayOf(id.toString())) }
    fun replaceFrom(json: JSONArray) {
        writableDatabase.beginTransaction()
        try {
            writableDatabase.delete("customers", null, null)
            for (i in 0 until json.length()) {
                val o = json.getJSONObject(i)
                val v = ContentValues().apply {
                    put("id", o.optLong("id")); put("name", o.optString("name"))
                    put("phone", o.optString("phone")); put("gender", o.optString("gender"))
                    put("email", o.optString("email")); put("date", o.optString("date"))
                    put("style", o.optString("style")); put("notes", o.optString("notes"))
                    put("unit", o.optString("unit", "in")); put("measurements", o.optJSONObject("measurements")?.toString() ?: "{}")
                }
                writableDatabase.insert("customers", null, v)
            }
            writableDatabase.setTransactionSuccessful()
        } finally { writableDatabase.endTransaction() }
    }
}

class BodyDiagram(ctx: Activity) : View(ctx) {
    var back = false
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val w = width.toFloat(); val h = height.toFloat()
        canvas.drawColor(PALE)
        val cx = w / 2f
        p.color = Color.rgb(185, 215, 153); p.style = Paint.Style.FILL
        val scale = minOf(w / 190f, h / 290f)
        canvas.save(); canvas.translate(cx - 95f * scale, 8f); canvas.scale(scale, scale)
        val path = Path()
        path.addCircle(95f, 20f, 13f, Path.Direction.CW)
        // Anatomical silhouette: head, neck, shoulders, torso, arms and legs.
        path.moveTo(85f, 35f); path.cubicTo(75f, 37f, 66f, 40f, 57f, 47f)
        path.lineTo(35f, 58f); path.quadTo(27f, 63f, 31f, 72f)
        path.quadTo(36f, 78f, 43f, 72f); path.lineTo(61f, 64f)
        path.lineTo(67f, 111f); path.lineTo(72f, 150f)
        path.lineTo(66f, 205f); path.quadTo(64f, 214f, 74f, 216f)
        path.quadTo(82f, 217f, 84f, 207f); path.lineTo(95f, 163f)
        path.lineTo(106f, 207f); path.quadTo(108f, 217f, 117f, 216f)
        path.quadTo(127f, 214f, 124f, 205f); path.lineTo(118f, 150f)
        path.lineTo(123f, 111f); path.lineTo(129f, 64f)
        path.lineTo(147f, 72f); path.quadTo(154f, 78f, 159f, 72f)
        path.quadTo(163f, 63f, 155f, 58f); path.lineTo(133f, 47f)
        path.cubicTo(124f, 40f, 115f, 37f, 105f, 35f)
        path.close()
        canvas.drawPath(path, p)
        p.color = DEEP; p.style = Paint.Style.STROKE; p.strokeWidth = 1.8f
        canvas.drawPath(path, p)
        p.strokeWidth = 1.2f
        val levels = listOf(62f to "Shoulder", 91f to "Chest", 119f to "Waist", 145f to "Hip")
        levels.forEach { (y, _) ->
            p.color = Color.rgb(119, 151, 77); p.pathEffect = DashPathEffect(floatArrayOf(4f, 4f), 0f)
            canvas.drawLine(45f, y, 145f, y, p)
        }
        p.pathEffect = null
        p.style = Paint.Style.FILL; p.color = DEEP; p.textSize = 10f
        canvas.drawText(if (back) "BACK VIEW" else "FRONT VIEW", 68f, 255f, p)
        canvas.restore()
    }
}

class MainActivity : Activity() {
    private lateinit var db: DbHelper
    private lateinit var root: LinearLayout
    private var currentEdit: Long = 0
    private var unit = "in"
    private var formFields = linkedMapOf<String, EditText>()
    private val groups = linkedMapOf(
        "Upper body" to listOf("Neck", "Shoulder", "Chest / bust", "Upper bust", "Under bust", "Armhole", "Sleeve length", "Upper arm", "Wrist", "Top length", "Back length", "Front length"),
        "Lower body" to listOf("Waist", "High hip", "Full hip", "Thigh", "Knee", "Calf", "Ankle", "Inside leg", "Outside leg", "Trouser length", "Skirt length"),
        "Other" to listOf("Head / cap", "Full height", "Dress length", "Crotch", "Other 1", "Other 2")
    )
    private val labels = groups.values.flatten()
    private val keys = labels.associateWith { it.lowercase(Locale.US).replace(Regex("[^a-z0-9]+"), "_").trim('_') }
    private val today get() = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())
    private var pdfBytes: ByteArray? = null
    private var backupBytes: ByteArray? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        db = DbHelper(this)
        showHome()
    }
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun text(s: String, size: Float = 15f, bold: Boolean = false): TextView =
        TextView(this).apply { text = s; textSize = size; setTextColor(INK); if (bold) setTypeface(null, 1); setPadding(0, dp(4), 0, dp(4)) }
    private fun button(s: String, action: () -> Unit, primary: Boolean = true): Button =
        Button(this).apply { text = s; isAllCaps = false; setTextColor(if (primary) Color.WHITE else DEEP); backgroundTintList = android.content.res.ColorStateList.valueOf(if (primary) DEEP else PALE); setOnClickListener { action() } }
    private fun base(title: String): LinearLayout {
        root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(Color.rgb(246, 250, 253)) }
        val header = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(18), dp(17), dp(18), dp(16)); setBackgroundColor(LIME) }
        header.addView(text("SIMON'S MEDFIT HUB", 12f, true))
        header.addView(text(title, 23f, true))
        header.addView(text("Designed for Care. Tailored for Professionals.", 11f))
        root.addView(header)
        val scroll = ScrollView(this)
        val body = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(14), dp(14), dp(14), dp(28)) }
        scroll.addView(body); root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
        return body
    }
    private fun card(body: LinearLayout, title: String) {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(14), dp(12), dp(14), dp(14)); background = android.graphics.drawable.GradientDrawable().apply { setColor(Color.WHITE); cornerRadius = dp(15).toFloat(); setStroke(dp(1), Color.rgb(218, 234, 244)) } }
        box.addView(text(title, 18f, true))
        body.addView(box, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(12) })
    }
    private fun showHome() {
        val body = base("Measurement Book")
        val all = db.all()
        val men = all.count { it.gender == "Male" }; val women = all.size - men
        val stats = text("CUSTOMERS  ${all.size}       MEN  $men       WOMEN  $women", 13f, true)
        body.addView(stats)
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(15), dp(15), dp(15), dp(15)); background = android.graphics.drawable.GradientDrawable().apply { setColor(Color.WHITE); cornerRadius = dp(15).toFloat() } }
        box.addView(button("+  Add new customer", { showForm() }))
        box.addView(button("All customers / Search", { showCustomers() }, false))
        box.addView(button("Backup and restore", { showBackup() }, false))
        body.addView(box)
        body.addView(text("Recent customers", 17f, true))
        all.take(5).forEach { c ->
            body.addView(button("${c.name}  ·  ID No.${c.id}", { showCustomer(c.id) }, false))
        }
        body.addView(text("Records are stored on this phone and work offline. Export a backup regularly.", 12f))
    }
    private fun addField(parent: LinearLayout, label: String, value: String = "", hint: String = ""): EditText {
        parent.addView(text("$label", 12f, true))
        val e = EditText(this).apply { setText(value); textSize = 15f; singleLine = true; setPadding(dp(11), dp(8), dp(11), dp(8)); this.hint = hint; background = android.graphics.drawable.GradientDrawable().apply { setColor(Color.WHITE); cornerRadius = dp(9).toFloat(); setStroke(dp(1), Color.LTGRAY) } }
        parent.addView(e, LinearLayout.LayoutParams(-1, dp(48)).apply { bottomMargin = dp(8) })
        return e
    }
    private fun showForm(existing: Customer? = null) {
        currentEdit = existing?.id ?: 0
        formFields.clear()
        val body = base(if (existing == null) "New customer" else "Edit customer")
        card(body, "Customer details")
        val card = body.getChildAt(body.childCount - 1) as LinearLayout
        val name = addField(card, "Customer name *", existing?.name ?: "")
        val phone = addField(card, "Phone number", existing?.phone ?: "")
        val email = addField(card, "Email", existing?.email ?: "")
        val style = addField(card, "Outfit / style", existing?.style ?: "")
        val date = addField(card, "Date measured (YYYY-MM-DD)", existing?.date ?: today)
        card.addView(text("Measurement profile", 12f, true))
        val gender = Spinner(this)
        gender.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, listOf("Female", "Male"))
        gender.setSelection(if (existing?.gender == "Male") 1 else 0)
        card.addView(gender)
        val diagram = BodyDiagram(this).apply { layoutParams = LinearLayout.LayoutParams(-1, dp(270)).apply { topMargin = dp(10); bottomMargin = dp(10) } }
        card.addView(diagram)
        val viewToggle = button("Switch front / back view", { diagram.back = !diagram.back; diagram.invalidate() }, false)
        card.addView(viewToggle)
        groups.forEach { (group, names) ->
            card.addView(text(group, 16f, true))
            names.forEach { label ->
                val key = keys[label]!!
                val value = existing?.measurements?.optString(key, "") ?: ""
                formFields[key] = addField(card, "$label ($unit)", value, "Enter measurement")
            }
        }
        val notes = addField(card, "Notes", existing?.notes ?: "")
        card.addView(button(if (existing == null) "Save customer" else "Update customer") {
            if (name.text.toString().trim().isEmpty()) { name.error = "Enter customer name"; return@button }
            val measurements = JSONObject()
            formFields.forEach { (k, v) -> if (v.text.toString().trim().isNotEmpty()) measurements.put(k, v.text.toString().trim()) }
            val c = Customer(existing?.id ?: 0, name.text.toString().trim(), phone.text.toString().trim(),
                gender.selectedItem.toString(), email.text.toString().trim(), date.text.toString().trim(),
                style.text.toString().trim(), notes.text.toString().trim(), unit, measurements)
            val id = db.save(c)
            Toast.makeText(this, "Saved as ID No.$id", Toast.LENGTH_LONG).show()
            showCustomer(id)
        })
        body.addView(button("Cancel", { showHome() }, false))
    }
    private fun showCustomers() {
        val body = base("All customers")
        val search = EditText(this).apply { hint = "Search name, phone or ID"; textSize = 15f }
        body.addView(search)
        val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        body.addView(list)
        fun render(q: String = "") {
            list.removeAllViews()
            db.all().filter { "${it.name} ${it.phone} ${it.id}".contains(q, true) }.forEach { c ->
                list.addView(button("${c.name}\nID No.${c.id}  ·  ${c.gender}  ·  ${c.date}", { showCustomer(c.id) }, false))
            }
        }
        search.addTextChangedListener(SimpleWatcher { render(it) })
        render()
        body.addView(button("Add customer", { showForm() }))
        body.addView(button("Home", { showHome() }, false))
    }
    private fun showCustomer(id: Long) {
        val c = db.all().firstOrNull { it.id == id } ?: run { showHome(); return }
        val body = base("Customer record")
        card(body, "${c.name}  ·  ID No.${c.id}")
        val box = body.getChildAt(body.childCount - 1) as LinearLayout
        box.addView(text("Profile: ${c.gender}     Date: ${c.date}"))
        box.addView(text("Phone: ${c.phone.ifBlank { "Not provided" }}"))
        box.addView(text("Email: ${c.email.ifBlank { "Not provided" }}"))
        box.addView(text("Style: ${c.style.ifBlank { "Not specified" }}"))
        groups.forEach { (group, names) ->
            val rows = names.mapNotNull { label ->
                val value = c.measurements.optString(keys[label], "")
                if (value.isBlank()) null else "$label: $value ${c.unit}"
            }
            if (rows.isNotEmpty()) {
                box.addView(text(group, 15f, true))
                rows.forEach { box.addView(text(it, 13f)) }
            }
        }
        box.addView(text("Notes: ${c.notes.ifBlank { "—" }}", 13f))
        body.addView(button("Generate PDF", { createPdf(c) }))
        body.addView(button("Edit measurements", { showForm(c) }, false))
        body.addView(button("Delete customer", {
            AlertDialog.Builder(this).setMessage("Delete ${c.name}'s record?").setNegativeButton("Cancel", null)
                .setPositiveButton("Delete") { _, _ -> db.delete(c.id); showCustomers() }.show()
        }, false))
        body.addView(button("Back to customers", { showCustomers() }, false))
    }
    private fun createPdf(c: Customer) {
        val doc = PdfDocument()
        val page = doc.startPage(PdfDocument.PageInfo.Builder(595, 842, 1).create())
        val canvas = page.canvas
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        p.color = DEEP; p.textSize = 22f; p.typeface = Typeface.create("sans-serif", Typeface.BOLD)
        canvas.drawText("SIMON'S MEDFIT HUB", 38f, 48f, p)
        p.color = INK; p.textSize = 17f
        canvas.drawText("CUSTOMER MEASUREMENT SHEET", 38f, 78f, p)
        p.textSize = 12f
        canvas.drawText("${c.name}   |   ID No.${c.id}", 38f, 108f, p)
        canvas.drawText("${c.gender}   |   ${c.date}   |   ${c.phone}", 38f, 128f, p)
        canvas.drawText("Style: ${c.style}", 38f, 148f, p)
        var y = 184f
        groups.forEach { (group, names) ->
            val rows = names.mapNotNull { label ->
                val value = c.measurements.optString(keys[label], "")
                if (value.isBlank()) null else label to value
            }
            if (rows.isNotEmpty()) {
                p.typeface = Typeface.DEFAULT_BOLD; p.textSize = 14f; p.color = DEEP
                canvas.drawText(group, 38f, y, p); y += 19f
                p.typeface = Typeface.DEFAULT; p.textSize = 11f; p.color = INK
                rows.forEach { (label, value) ->
                    canvas.drawLine(38f, y + 5f, 555f, y + 5f, p)
                    canvas.drawText(label, 44f, y, p); canvas.drawText("$value ${c.unit}", 360f, y, p); y += 21f
                    if (y > 790f) return@forEach
                }
                y += 12f
            }
        }
        p.textSize = 10f
        canvas.drawText("Notes: ${c.notes}", 38f, minOf(y + 8f, 815f), p)
        doc.finishPage(page)
        val out = ByteArrayOutputStream(); doc.writeTo(out); doc.close()
        pdfBytes = out.toByteArray()
        val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE); type = "application/pdf"
            putExtra(Intent.EXTRA_TITLE, "MedFit_ID_${c.id}_${c.name.replace(" ", "_")}.pdf")
        }
        startActivityForResult(intent, 101)
    }
    private fun showBackup() {
        val body = base("Backup & restore")
        card(body, "Keep your customer records safe")
        val box = body.getChildAt(body.childCount - 1) as LinearLayout
        box.addView(text("Your records are stored locally on this phone. Create a backup file regularly and save it in a safe place, such as Google Drive."))
        body.addView(button("Export backup file", {
            val arr = JSONArray()
            db.all().forEach { c ->
                arr.put(JSONObject().apply {
                    put("id", c.id); put("name", c.name); put("phone", c.phone); put("gender", c.gender)
                    put("email", c.email); put("date", c.date); put("style", c.style); put("notes", c.notes)
                    put("unit", c.unit); put("measurements", c.measurements)
                })
            }
            backupBytes = JSONObject().put("app", "MedFit Measurement Book").put("records", arr).toString(2).toByteArray()
            val i = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
                addCategory(Intent.CATEGORY_OPENABLE); type = "application/json"; putExtra(Intent.EXTRA_TITLE, "MedFit_Backup.json")
            }
            startActivityForResult(i, 102)
        }))
        body.addView(button("Restore backup file", {
            val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply { addCategory(Intent.CATEGORY_OPENABLE); type = "*/*" }
            startActivityForResult(i, 103)
        }, false))
        body.addView(button("Home", { showHome() }, false))
        body.addView(text("Important: restoring a backup replaces the records currently on this phone."))
    }
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != RESULT_OK || data?.data == null) return
        val uri = data.data!!
        when (requestCode) {
            101 -> { pdfBytes?.let { contentResolver.openOutputStream(uri)?.use { stream -> stream.write(it) } }; Toast.makeText(this, "PDF saved", Toast.LENGTH_LONG).show() }
            102 -> { backupBytes?.let { contentResolver.openOutputStream(uri)?.use { stream -> stream.write(it) } }; Toast.makeText(this, "Backup exported", Toast.LENGTH_LONG).show() }
            103 -> try {
                val raw = contentResolver.openInputStream(uri)?.bufferedReader()?.readText() ?: ""
                val arr = JSONObject(raw).getJSONArray("records")
                AlertDialog.Builder(this).setMessage("Restore ${arr.length()} customer records? This replaces the current records.")
                    .setNegativeButton("Cancel", null).setPositiveButton("Restore") { _, _ -> db.replaceFrom(arr); showHome() }.show()
            } catch (_: Exception) { Toast.makeText(this, "Could not read this backup file", Toast.LENGTH_LONG).show() }
        }
    }
}

class SimpleWatcher(val changed: (String) -> Unit) : android.text.TextWatcher {
    override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
    override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) { changed(s?.toString() ?: "") }
    override fun afterTextChanged(s: android.text.Editable?) {}
}
