# MedFit Measurement Book — Android project

An offline-first native Android starter app for Simon's MedFit Hub. Brand palette: navy blue, white and sky blue.

## Included
- Local SQLite customer database (no internet required for everyday use)
- Automatic customer IDs (`ID No.1`, `ID No.2`, ...)
- Male/female customer profile
- Measurement fields grouped by upper body, lower body and other
- Front/back body illustration toggle
- Search, view, edit and delete customer records
- PDF export through Android's Save dialog
- JSON backup export and restore through Android's file picker

## Build an APK
This workspace contains the Android Studio project source, not a compiled APK.

1. Install Android Studio on a computer.
2. Open this `MedFitMeasurementBook` folder in Android Studio.
3. Allow Android Studio to download the Gradle and Android build components.
4. Connect an Android phone with USB debugging enabled, or use an emulator.
5. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
6. Android Studio will show the generated APK location, usually `app/build/outputs/apk/debug/app-debug.apk`.

## Important data note
Customer data is stored in the app's private SQLite database on the phone. Export a JSON backup regularly using **Backup and restore**. Store backups privately because they contain customer contact and measurement information. Restoring a backup replaces the current local records.

## Customisation status
Custom outfit templates and user-managed measurement fields (add, rename, reorder and remove) are planned but are not implemented in this starter yet.

## Next development steps
- Replace the illustrative body outline with detailed front/back male and female measurement diagrams.
- Add configurable measurement templates for scrubs, lab coats, trousers, dresses and other garments.
- Add measurement history per customer and optional cloud backup.
- Add app icon, splash screen, accessibility and device testing.
